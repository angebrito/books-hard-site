export interface Livro {
    id: number,
    title: String,
    author: String,
    date: number,
    img: String,
    category: String,
    body: String,
    read: String,
    pdf: String,
    epub: String,
    mobi: String
}